<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use App\Models\Lector;

use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $lectores = Lector::all();
        $users = User::all();
        $posts = Post::all();
        $tabla = DB::table('posts')
            ->join('users', 'posts.user_id', '=', 'users.id')
            ->get();
        return view('dashboard')
            ->with('lectores', $lectores)
            ->with('users', $users)
            ->with('tabla', $tabla)
            ->with('posts', $posts);
    }
}
