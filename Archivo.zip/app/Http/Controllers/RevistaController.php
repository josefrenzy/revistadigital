<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Edicion;
use App\Models\Post;

class RevistaController extends Controller
{

    public function index()
    {   
        $last_edicion = DB::select('select * from ediciones order by id asc limit 1');
        $posts = DB::select('select *, posts.id as post_id from posts
        inner join ediciones on posts.ediciones_id = ediciones.id
        inner join abstract on posts.abstract_id = abstract.id
        where ediciones.nombre = ? order by created_at desc limit 1', [$last_edicion[0]->nombre]);
        $flash = DB::select('select * from flash order by created_at desc limit 1');
        // $posts = Post::find(1);
        $capsulas = DB::select('select * from capsula order by id desc limit 2');
        $art = DB::select('select a.nombre, a.descripcion, p.id , a.img_abstract
            from posts as p 
            inner join abstract as a order by id desc limit 1');
        $cat = DB::select('select * from categorias order by id desc limit 3'); //
        $nombreEdicion = DB::select('select * from ediciones order by id desc limit 1');
        $categories = Category::all();
        $ediciones = Edicion::all();
        return view('main.revista')
            ->with('art', $art)
            ->with('cat', $cat)
            ->with('flash', $flash)
            ->with('posts', $posts)
            ->with('capsulas', $capsulas)
            ->with('ediciones', $ediciones)
            ->with('categories', $categories)
            ->with('nombreEdicion', $nombreEdicion);
    }
    public function show($id)
    {
        $post = Post::find($id);
        // $post = DB::select('select * from posts where id = 1');//, [$id]);
        $latest = DB::select('select * from abstract order by id desc limit 2');
        $capsulas = DB::select('select * from capsula order by id desc limit 2');
        $art = DB::select('select a.nombre, a.descripcion, p.id , a.img_abstract
            from posts as p 
            inner join abstract as a order by id desc limit 1');
        $categories = Category::all();
        return view('main.show')
            ->with('art', $art)
            ->with('post', $post)
            ->with('latest', $latest)
            ->with('capsulas', $capsulas)
            ->with('categories', $categories);
    }
}
