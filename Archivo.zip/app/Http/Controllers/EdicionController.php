<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Edicion;
use App\Models\Category;

use Illuminate\Support\Facades\DB;

class EdicionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ediciones = Edicion::all();
        return view('ediciones.index')
            ->with('ediciones', $ediciones);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('ediciones.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Edicion::create($request->all());
        return back() //redirect()->route('ediciones.index')
            ->with('success', 'Edición creada correctamente.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($nombre)
    {
        $ediciones = DB::table('posts')
            ->join('ediciones', 'posts.ediciones_id', '=', 'ediciones.id')
            ->where('ediciones.nombre','=',$nombre)
            ->get();
        // dd($ediciones);
        $latest = DB::select('select * from abstract order by id desc limit 2');
        $capsulas = DB::select('select * from capsula order by id desc limit 2');
        $art = DB::select('select a.nombre, a.descripcion, p.id , a.img_abstract
            from posts as p 
            inner join abstract as a order by id desc limit 1');
        $categories = Category::all();
        return view('ediciones.show')
            ->with('ediciones',$ediciones)
            ->with('art', $art)
            ->with('latest', $latest)
            ->with('capsulas', $capsulas)
            ->with('categories', $categories);
            
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ediciones = Edicion::findOrFail($id);
        return view('ediciones.edit')
            ->with('ediciones', $ediciones);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data =  $request->except('_token', '_method');
        Edicion::where('id', $id)
            ->update($data);
        return back()
            ->with('success', 'Edicion modificada correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Edicion::destroy($id);
        return redirect('ediciones.index')
            ->with('success', 'Categoria eliminado correctamente.');
    }
}
